(self["webpackChunkjupyterlab_remote_contents"] = self["webpackChunkjupyterlab_remote_contents"] || []).push([["lib_index_js"],{

/***/ "./lib/commands.js":
/*!*************************!*\
  !*** ./lib/commands.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addContextMenuCommands: () => (/* binding */ addContextMenuCommands),
/* harmony export */   addNotebookToolbarMenu: () => (/* binding */ addNotebookToolbarMenu)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mdi_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mdi/js */ "webpack/sharing/consume/default/@mdi/js/@mdi/js");
/* harmony import */ var _mdi_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mdi_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./icons */ "./lib/icons.js");
/* harmony import */ var _drive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./drive */ "./lib/drive.js");
/* harmony import */ var _snippets__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./snippets */ "./lib/snippets.js");







const ORIGIN = window.parent.location.origin;
const showErrorDialog = (body, title) => {
    (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
        title,
        body,
        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton({ label: 'OK' })]
    });
};
async function insertCode({ commands, notebookTracker, app, widget }, args) {
    // Get the active notebook
    const currentNotebook = notebookTracker.currentWidget;
    if (!currentNotebook) {
        showErrorDialog('Please create or open a notebook before executing this action.', 'No notebook open');
        return;
    }
    const snippet = args.snippet;
    const notebookPanel = currentNotebook;
    const notebook = notebookPanel.content;
    if (notebook.activeCell) {
        // Ensure the active cell's model is properly accessed
        const activeCellModel = notebook.activeCell.model;
        if (activeCellModel && activeCellModel.sharedModel) {
            const currentSource = activeCellModel.sharedModel.getSource();
            activeCellModel.sharedModel.setSource(currentSource + '\n' + snippet);
        }
    }
    else {
        // Insert a new cell below if no active cell
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookActions.insertBelow(notebook);
        // Access the newly created cell safely
        const newActiveCell = notebook.activeCell;
        if (newActiveCell && newActiveCell.model && newActiveCell.model.sharedModel) {
            newActiveCell.model.sharedModel.setSource(snippet);
        }
    }
    // Ensure the notebook panel is focused
    notebookPanel.content.activate();
}
async function insertDataImportCode({ commands, notebookTracker, app, widget }) {
    const item = widget.selectedItems().next();
    if (!item) {
        return;
    }
    const pathStr = item.value.path;
    // Remove the drive name from the path
    const path = pathStr.split(':').slice(1).join(':');
    // Lookup the file
    const drive = new _drive__WEBPACK_IMPORTED_MODULE_4__.Drive();
    const file = await drive.lookup(path);
    if (!file) {
        showErrorDialog(`Failed to load file with path ${path}.`, 'File loading error');
        return;
    }
    else if (file.filetype !== 'grid') {
        showErrorDialog('Only data grid contents can be currently imported.', 'Unsupported file type');
        return;
    }
    const parsedFid = file.fid.split(':');
    const URL = ORIGIN + '/~' + parsedFid[0] + '/' + parsedFid[1] + '.csv';
    const snippet = `# Patch http requests (required for importing data into Python execution environment) \nimport pyodide_http\npyodide_http.patch_all()\n# Load data from ${file.filename} to Pandas dataframe\nimport pandas as pd\ndata = pd.read_csv('${URL}')\ndata.head()`;
    // Insert the code into the active cell
    insertCode({ commands, notebookTracker, app, widget }, { snippet });
}
const CONTEXT_MENU_COMMANDS = [
    {
        'command': 'filebrowser:fq-insert-data-import-code',
        'label': 'Import Data to Pandas Dataframe',
        'icon': _mdi_js__WEBPACK_IMPORTED_MODULE_3__.mdiViewGridPlusOutline,
        'execute': insertDataImportCode,
    },
];
function addContextMenuCommands(commands, notebookTracker, app, widget) {
    const infra = {
        commands,
        notebookTracker,
        app,
        widget
    };
    // Add commands from COMMANDS
    CONTEXT_MENU_COMMANDS.forEach(({ command, label, icon, execute }) => {
        const iconName = command + '-icon';
        commands.addCommand(command, {
            label: label,
            icon: (0,_icons__WEBPACK_IMPORTED_MODULE_5__.createIcon)(iconName, icon),
            execute: () => {
                execute(infra);
            }
        });
    });
    // Create a new sub-menu
    const subMenu = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Menu({ commands });
    subMenu.title.label = 'Figlinq Actions'; // Name of the pull-down menu
    CONTEXT_MENU_COMMANDS.forEach((item) => {
        subMenu.addItem({ command: item.command });
    });
    // Add the separator and sub-menu to the context menu
    app.contextMenu.addItem({
        type: 'separator', // Add a divider
        selector: '.jp-DirListing-item', // Ensure it appears in the same context
        rank: 9.9, // Choose a rank slightly less than the submenu to place it before
    });
    app.contextMenu.addItem({
        type: 'submenu', // Indicate it's a sub-menu
        submenu: subMenu, // Attach the sub-menu
        selector: '.jp-DirListing-item', // Selector for the context menu item
        rank: 10, // Rank in the context menu
    });
}
// #######################################

const TOOLBAR_MENU_COMMANDS = [
    {
        command: 'notebook:fq-insert-chart-studio-import',
        label: 'Import packages to interact with Figlinq',
        'execute': insertCode,
        'args': { snippet: _snippets__WEBPACK_IMPORTED_MODULE_6__.SNIPPETS.installChartStudio }
    },
    {
        command: 'notebook:fq-insert-http-patch',
        label: 'Patch http requests to interact with external contents',
        'execute': insertCode,
        'args': { snippet: _snippets__WEBPACK_IMPORTED_MODULE_6__.SNIPPETS.patchHttp }
    },
    // {
    //   command: 'notebook:fq-clear-all-cells',
    //   label: 'Clear All Cells',
    //   execute: () => {
    //     const currentNotebook = notebookTracker.currentWidget?.content;
    //     if (currentNotebook) {
    //       NotebookActions.clearAllOutputs(currentNotebook);
    //     }
    //   }
    // },
    // {
    //   command: 'notebook:fq-run-all-cells',
    //   label: 'Run All Cells',
    //   execute: () => {
    //     const currentNotebook = notebookTracker.currentWidget?.content;
    //     if (currentNotebook) {
    //       NotebookActions.runAll(currentNotebook);
    //     }
    //   }
    // }
];
function addNotebookToolbarMenu(commands, notebookTracker, app) {
    // Define the commands for the pull-down menu
    // Register the commands
    TOOLBAR_MENU_COMMANDS.forEach(({ command, label, execute, args }) => {
        commands.addCommand(command, {
            label,
            execute: () => {
                const widget = app.shell.currentWidget;
                execute({ commands, notebookTracker, app, widget }, args);
            }
        });
    });
    // Create a drop-down menu
    const menu = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Menu({ commands });
    TOOLBAR_MENU_COMMANDS.forEach(({ command }) => {
        menu.addItem({ command });
    });
    // Create a toolbar button that opens the menu
    const menuButton = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ToolbarButton({
        label: 'Figlinq Actions',
        onClick: () => {
            menu.open(menuButton.node.getBoundingClientRect().x, menuButton.node.getBoundingClientRect().bottom);
        },
        icon: (0,_icons__WEBPACK_IMPORTED_MODULE_5__.createFiglinqIcon)(),
    });
    // Add the toolbar button to the notebook toolbar
    app.docRegistry.addWidgetExtension('Notebook', {
        createNew: (panel) => {
            panel.toolbar.insertItem(11, 'figlinq-menu', menuButton);
            return undefined;
        }
    });
}


/***/ }),

/***/ "./lib/drive.js":
/*!**********************!*\
  !*** ./lib/drive.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Drive: () => (/* binding */ Drive),
/* harmony export */   SERVICE_DRIVE_URL: () => (/* binding */ SERVICE_DRIVE_URL)
/* harmony export */ });
/* harmony import */ var _serverconnection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./serverconnection */ "./lib/serverconnection.js");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./icons */ "./lib/icons.js");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__);






/**
 * The url for the default drive service.
 */
const SERVICE_DRIVE_URL = 'v2/';
/**
 * The url for the file access.
 */
const FILES_URL = 'files';
const EMPTY_NOTEBOOK = {
    cells: [],
    metadata: {},
    nbformat: 4,
    nbformat_minor: 5
};
/**
 * Mapping of plotly filetype to Jupyter file type.
 */
const FILETYPE_TO_TYPE = {
    'fold': 'directory',
    'html_text': 'file',
    'grid': 'file',
    'plot': 'file',
    'external_image': 'file',
    'jupyter_notebook': 'notebook',
};
const TYPE_TO_MIMETYPE = {
    'directory': 'application/x-directory',
    'file': 'text/plain',
    'notebook': 'application/x-ipynb+json',
};
const TYPE_TO_FORMAT = {
    'directory': 'json',
    'file': 'text',
    'notebook': 'json',
};
/**
 * A default implementation for an `IDrive`, talking to the
 * server using the Jupyter REST API.
 */
class Drive {
    /**
     * Construct a new contents manager object.
     *
     * @param options - The options used to initialize the object.
     */
    constructor(options = {
        browser: _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__.IFileBrowserFactory
    }) {
        this.browser = options.browser;
        this.name = options.name ?? 'Default';
        this._apiEndpoint = options.apiEndpoint ?? SERVICE_DRIVE_URL;
        this.serverSettings =
            options.serverSettings ?? _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeSettings();
    }
    /**
     * The name of the drive, which is used at the leading
     * component of file paths.
     */
    name;
    /**
     * The file browser factory.
     * This is used to refresh the file browser after a file operation.
     */
    browser;
    /**
     * A signal emitted when a file operation takes place.
     */
    get fileChanged() {
        return this._fileChanged;
    }
    /**
     * The server settings of the drive.
     */
    serverSettings;
    /**
     * Test whether the manager has been disposed.
     */
    get isDisposed() {
        return this._isDisposed;
    }
    /**
     * Dispose of the resources held by the manager.
     */
    dispose() {
        if (this.isDisposed) {
            return;
        }
        this._isDisposed = true;
        _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal.clearData(this);
    }
    async lookup(localPath) {
        const args = ['files', 'lookup'];
        const url = this._getUrl(...args);
        let params = { path: localPath };
        const response = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeRequest(this.serverSettings, url, {}, params);
        if (response.status !== 200) {
            const err = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.ResponseError.create(response);
            throw err;
        }
        let data = await response.json();
        return data;
    }
    async createRevision(fid) {
        const args = ['files', fid, 'revisions'];
        const url = this._getUrl(...args);
        const init = {
            method: 'POST',
        };
        const params = {};
        const response = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeRequest(this.serverSettings, url, init, params);
        if (response.status !== 201 && response.status !== 204) {
            const err = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.ResponseError.create(response);
            console.error('createRevision error', err);
            (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.showDialog)({
                title: 'Error',
                body: err.message,
                buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.Dialog.okButton()]
            });
        }
    }
    // async restore(fid: string): Promise<any>{
    //   const args = ['files', fid, 'restore'];
    //   const url = this._getUrl(...args);
    //   const response = await ServerConnection.makeRequest(this.serverSettings, url, {method: 'POST'});
    //   if (response.status !== 200) {
    //     const err = await ServerConnection.ResponseError.create(response);
    //     console.log('restore error', err);
    //     throw err;
    //   }
    //   let data = await response.json();
    //   return data;
    // }
    /**
     * Get a file or directory.
     *
     * @param localPath: The path to the file.
     *
     * @param options: The options used to fetch the file.
     *
     * @returns A promise which resolves with the file content.
     *
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents) and validates the response model.
     */
    async get(localPath, options) {
        // console.log('get', localPath, options);
        let filetype = 'fold';
        let lookup;
        let filename = '';
        let pathParts = [];
        let params = {};
        // We need to do a lookup first to determine the appropriate api path
        if (localPath) {
            lookup = await this.lookup(localPath);
            // Get the filetype and filename from the lookup      
            filetype = lookup.filetype;
            filename = lookup.filename;
            if (filetype === 'fold') {
                pathParts = ['folders', lookup.fid];
                params = { page: 1, page_size: 100000, order_by: 'filename' };
            }
            else if (filetype === 'jupyter_notebook') {
                pathParts = ['jupyter-notebooks', lookup.fid, 'content'];
            }
            else {
                throw new Error("Currently you can only open notebooks and folders!");
            }
        }
        else { // For home directory we do not need to do a lookup  
            pathParts = ['folders', 'home'];
            params = { page: 1, page_size: 100000, order_by: 'filename' };
            lookup = {
                date_modified: '',
                creation_time: '',
            };
        }
        const url = this._getUrl(...pathParts);
        // if (options) {
        //   // The notebook type cannot take a format option.
        //   if (options.type === 'notebook') {
        //     delete options['format'];
        //   }
        //   const content = options.content ? '1' : '0';
        //   params = {...params, ...options, content };
        // }
        const response = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeRequest(this.serverSettings, url, {}, params);
        if (response.status !== 200) {
            console.log(response.json());
            const err = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.ResponseError.create(response);
            throw err;
        }
        let data = await response.json();
        const convOptions = {
            data: data?.file || data,
            type: FILETYPE_TO_TYPE[filetype],
            name: filename,
            path: localPath,
            last_modified: lookup.date_modified,
            created: lookup.creation_time,
        };
        let model;
        try {
            model = Private.convertToJupyterApi(convOptions);
        }
        catch (error) {
            console.error('Error converting to Jupyter API', error);
        }
        Private.validateContentsModel(model);
        return model;
    }
    /**
     * Get an encoded download url given a file path.
     *
     * @param localPath - An absolute POSIX file path on the server.
     *
     * #### Notes
     * It is expected that the path contains no relative paths.
     *
     * The returned URL may include a query parameter.
     */
    getDownloadUrl(localPath) {
        const baseUrl = this.serverSettings.baseUrl;
        let url = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.URLExt.join(baseUrl, FILES_URL, _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.URLExt.encodeParts(localPath));
        const xsrfTokenMatch = document.cookie.match('\\b_xsrf=([^;]*)\\b');
        if (xsrfTokenMatch) {
            const fullUrl = new URL(url);
            fullUrl.searchParams.append('_xsrf', xsrfTokenMatch[1]);
            url = fullUrl.toString();
        }
        return Promise.resolve(url);
    }
    /**
     * Saves existing notebook in the specified directory path.
     *
     * @param options: The options used to create the file, including content
     *
     * @returns A promise which resolves with the created file content when the
     *    file is created.
     *
     * #### Notes
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents) and validates the response model.
     */
    async saveNotebookAs(options) {
        console.log('saveNotebookAs', options);
        let args = [];
        let body;
        let headers;
        let fileName = 'Untitled notebook.ipynb';
        let refreshBrowser = false;
        let parentIdLocal;
        const splitPath = options.path.split('/');
        if (splitPath.length === 1) { // Home directory, with just filename provided in path
            parentIdLocal = -1;
            fileName = options.path;
            refreshBrowser = true;
        }
        else { // In subdirectory
            const parentPath = splitPath.slice(0, splitPath.length - 1).join('/');
            const parentLookup = await this.lookup(parentPath);
            const parentFid = parentLookup.fid;
            parentIdLocal = parseInt(parentFid.split(':')[1]);
            fileName = splitPath[splitPath.length - 1];
        }
        args = ['jupyter-notebooks', 'upload'];
        body = JSON.stringify(options.content);
        headers = {
            'plotly-parent': `${parentIdLocal}`,
            'plotly-world-readable': 'false',
            'x-file-name': fileName,
            'content-type': 'application/json',
        };
        const url = this._getUrl(...args);
        const init = {
            method: 'POST',
            body,
            headers,
        };
        const response = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeRequest(this.serverSettings, url, init);
        if (response.status !== 201) {
            const err = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.ResponseError.create(response);
            throw err;
        }
        const data = await response.json();
        const convOptions = {
            data: data.file,
            type: options.type,
            name: data.file.filename,
            path: options.path,
            last_modified: data.file.date_modified,
            created: data.file.creation_time,
        };
        // Transform the API response to a Contents.IModel
        let model;
        try {
            model = Private.convertToJupyterApi(convOptions);
        }
        catch (error) {
            console.error('Error converting to Jupyter API', error);
        }
        Private.validateContentsModel(model);
        this._fileChanged.emit({
            type: 'new',
            oldValue: null,
            newValue: model
        });
        if (refreshBrowser) {
            this.refreshBrowser();
        }
        return model;
    }
    /**
     * Create a new untitled file or directory in the specified directory path.
     *
     * @param options: The options used to create the file.
     *
     * @returns A promise which resolves with the created file content when the
     *    file is created.
     *
     * #### Notes
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents) and validates the response model.
     */
    async newUntitled(options = {}) {
        console.log('newUntitled', options);
        let args = [];
        let body;
        let headers;
        let fileName = 'Untitled notebook.ipynb';
        let refreshBrowser = false;
        if (options.type === 'notebook') {
            console.log('newUntitled notebook');
            let parent;
            if (!options.path) { // Home directory
                parent = -1;
                refreshBrowser = true;
            }
            else { // In subdirectory
                const parentLookup = await this.lookup(options.path);
                const parentFid = parentLookup.fid;
                parent = parseInt(parentFid.split(':')[1]);
            }
            args = ['jupyter-notebooks', 'upload'];
            body = JSON.stringify(EMPTY_NOTEBOOK);
            headers = {
                'plotly-parent': `${parent}`,
                'plotly-world-readable': 'false',
                'x-file-name': fileName,
                'content-type': 'application/json',
            };
        }
        else if (options.type === 'directory') {
            console.log('newUntitled directory');
            fileName = 'Unnamed Folder';
            args = ['folders'];
            let parent;
            if (!options.path) {
                parent = -1;
            }
            else {
                const lookup = await this.lookup(options.path);
                const fid = lookup.fid;
                parent = fid.split(':')[1];
            }
            body = JSON.stringify({
                "parent": parent,
                "path": "Unnamed Folder",
            });
            headers = {
                'content-type': 'application/json',
            };
        }
        const url = this._getUrl(...args);
        const init = {
            method: 'POST',
            body,
            headers,
        };
        const response = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeRequest(this.serverSettings, url, init);
        if (response.status !== 201) {
            const err = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.ResponseError.create(response);
            throw err;
        }
        const data = await response.json();
        const newFileName = data.file.filename;
        const newLocalPath = options.path ? `${options.path}/${newFileName}` : newFileName;
        const convOptions = {
            data: data.file,
            type: options.type,
            name: newFileName,
            path: newLocalPath,
            last_modified: data.file.date_modified,
            created: data.file.creation_time,
        };
        // Transform the API response to a Contents.IModel
        let model;
        try {
            model = Private.convertToJupyterApi(convOptions);
        }
        catch (error) {
            console.error('Error converting data to Jupyter API', error);
        }
        Private.validateContentsModel(model);
        this._fileChanged.emit({
            type: 'new',
            oldValue: null,
            newValue: model
        });
        if (refreshBrowser) {
            this.refreshBrowser();
        }
        return model;
    }
    /**
     * Delete a file.
     *
     * @param localPath - The path to the file.
     *
     * @returns A promise which resolves when the file is deleted.
     *
     * #### Notes
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents).
     */
    async delete(localPath) {
        const lookup = await this.lookup(localPath);
        const fid = lookup.fid;
        const parent = lookup.parent;
        const url = this._getUrl(...['files', fid, 'trash']);
        const init = { method: 'POST' };
        const response = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeRequest(this.serverSettings, url, init);
        if (response.status !== 200) {
            const err = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.ResponseError.create(response);
            throw err;
        }
        this._fileChanged.emit({
            type: 'delete',
            oldValue: { path: localPath },
            newValue: null
        });
        if (parent === -1) {
            this.refreshBrowser();
        }
    }
    /**
     * Rename a file or directory.
     *
     * @param oldLocalPath - The original file path.
     *
     * @param newLocalPath - The new file path.
     *
     * @returns A promise which resolves with the new file contents model when
     *   the file is renamed.
     *
     * #### Notes
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents) and validates the response model.
     */
    async rename(oldLocalPath, newLocalPath) {
        console.log('rename', oldLocalPath, newLocalPath);
        const fileLookup = await this.lookup(oldLocalPath);
        // Renaming can include moving the file to a new directory, in this case we need check the parent in newLocalPath vs oldLocalPath (find last posix part)
        // Last part is the file. Prior parts are the directories.
        const oldPathParts = oldLocalPath.split('/');
        const newPathParts = newLocalPath.split('/');
        const newFileName = newPathParts[newPathParts.length - 1];
        const oldParentPath = oldPathParts.slice(0, oldPathParts.length - 1).join('/');
        const newParentPath = newPathParts.slice(0, newPathParts.length - 1).join('/');
        let newParentIdlocal;
        if (newParentPath === '') { // root directory
            newParentIdlocal = -1;
        }
        else if (oldParentPath !== newParentPath) { // moving to a new directory
            const newParentLookup = await this.lookup(newParentPath);
            newParentIdlocal = newParentLookup.fid.split(':')[1];
            newParentIdlocal = parseInt(newParentIdlocal);
        }
        else { // same directory
            newParentIdlocal = fileLookup.parent;
        }
        // PATCH /files/{fid}
        let pathParts = [];
        pathParts.push('files');
        pathParts.push(fileLookup.fid);
        const url = this._getUrl(...pathParts);
        fileLookup.filename = newFileName;
        fileLookup.parent = newParentIdlocal;
        const apiObj = {
            "filename": newFileName,
            "parent": newParentIdlocal,
            "fid": fileLookup.fid,
        };
        const headers = {
            'content-type': 'application/json',
        };
        const init = {
            method: 'PATCH',
            body: JSON.stringify(apiObj),
            headers,
        };
        const response = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeRequest(this.serverSettings, url, init);
        if (response.status !== 200) {
            const err = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.ResponseError.create(response);
            throw err;
        }
        const data = await response.json();
        const convOptions = {
            data: null,
            type: FILETYPE_TO_TYPE[fileLookup.filetype],
            name: newFileName,
            path: newLocalPath,
            last_modified: data.date_modified,
            created: data.creation_time,
        };
        let model;
        try {
            model = Private.convertToJupyterApi(convOptions);
        }
        catch (error) {
            console.error('Error converting to Jupyter API', error);
        }
        Private.validateContentsModel(model);
        this._fileChanged.emit({
            type: 'rename',
            oldValue: { path: oldLocalPath },
            newValue: { path: newLocalPath },
        });
        this.refreshBrowser();
        return model;
    }
    /**
     * Save a file.
     *
     * @param localPath - The desired file path.
     *
     * @param options - Optional overrides to the model.
     *
     * @returns A promise which resolves with the file content model when the
     *   file is saved.
     *
     * #### Notes
     * Ensure that `model.content` is populated for the file.
     *
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents) and validates the response model.
     */
    async save(localPath, options = {}) {
        console.log('save', localPath, options);
        let lookup;
        // Jupyterlite deletes the file and creates a new one, so we need to restore it from the trash if it is trashed
        try {
            lookup = options.path ? await this.lookup(options.path) : null;
        }
        catch {
            // File does not exist, saving a new file
            return this.saveNotebookAs(options);
        }
        const body = JSON.stringify({ content: JSON.stringify(options.content) });
        const headers = {
            'content-type': 'application/json',
        };
        const url = this._getUrl(...['jupyter-notebooks', lookup.fid]);
        const init = {
            method: 'PATCH',
            body,
            headers,
        };
        const response = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeRequest(this.serverSettings, url, init);
        // will return 200 for an existing file and 201 for a new file
        if (response.status !== 200 && response.status !== 201) {
            const err = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.ResponseError.create(response);
            throw err;
        }
        const data = await response.json();
        // Create a revision
        await this.createRevision(lookup.fid);
        const convOptions = {
            data: null,
            type: FILETYPE_TO_TYPE[lookup.filetype],
            name: lookup.filename,
            path: localPath,
            last_modified: data.date_modified,
            created: data.creation_time,
        };
        const model = Private.convertToJupyterApi(convOptions);
        Private.validateContentsModel(model);
        this._fileChanged.emit({
            type: 'save',
            oldValue: null,
            newValue: model
        });
        return model;
    }
    /**
     * Copy a file into a given directory.
     *
     * @param localPath - The original file path.
     *
     * @param toDir - The destination directory path.
     *
     * @returns A promise which resolves with the new contents model when the
     *  file is copied.
     *
     * #### Notes
     * The server will select the name of the copied file.
     *
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents) and validates the response model.
     */
    async copy(fromFile, toDir) {
        const url = this._getUrl(toDir);
        const init = {
            method: 'POST',
            body: JSON.stringify({ copy_from: fromFile })
        };
        const response = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeRequest(this.serverSettings, url, init);
        if (response.status !== 201) {
            const err = await _serverconnection__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.ResponseError.create(response);
            throw err;
        }
        const data = await response.json();
        Private.validateContentsModel(data);
        this._fileChanged.emit({
            type: 'new',
            oldValue: null,
            newValue: data
        });
        return data;
    }
    /**
     * Create a checkpoint for a file. Disabled for now.
     *
     * @param localPath - The path of the file.
     *
     * @returns A promise which resolves with the new checkpoint model when the
     *   checkpoint is created.
     *
     * #### Notes
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents) and validates the response model.
     */
    async createCheckpoint(localPath) {
        // const url = this._getUrl(localPath, 'checkpoints');
        // const init = { method: 'POST' };
        // const response = await ServerConnection.makeRequest(
        //   url,
        //   init,
        //   this.serverSettings
        // );
        // if (response.status !== 201) {
        //   const err = await ServerConnection.ResponseError.create(response);
        //   throw err;
        // }
        // const data = await response.json();
        // Private.validateCheckpointModel(data);
        // return data;
        return {
            id: 'no-op',
            last_modified: new Date().toISOString()
        };
    }
    /**
     * List available checkpoints for a file. Disabled for now.
     *
     * @param localPath - The path of the file.
     *
     * @returns A promise which resolves with a list of checkpoint models for
     *    the file.
     *
     * #### Notes
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents) and validates the response model.
     */
    async listCheckpoints(localPath) {
        // const url = this._getUrl(localPath, 'checkpoints');
        // const response = await ServerConnection.makeRequest(
        //   url,
        //   {},
        //   this.serverSettings
        // );
        // if (response.status !== 200) {
        //   const err = await ServerConnection.ResponseError.create(response);
        //   throw err;
        // }
        // const data = await response.json();
        // if (!Array.isArray(data)) {
        //   throw new Error('Invalid Checkpoint list');
        // }
        // for (let i = 0; i < data.length; i++) {
        //   Private.validateCheckpointModel(data[i]);
        // }
        // return data;
        return [];
    }
    /**
     * Restore a file to a known checkpoint state.  Disabled for now.
     *
     * @param localPath - The path of the file.
     *
     * @param checkpointID - The id of the checkpoint to restore.
     *
     * @returns A promise which resolves when the checkpoint is restored.
     *
     * #### Notes
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents).
     */
    async restoreCheckpoint(localPath, checkpointID) {
        // const url = this._getUrl(localPath, 'checkpoints', checkpointID);
        // const init = { method: 'POST' };
        // const response = await ServerConnection.makeRequest(
        //   url,
        //   init,
        //   this.serverSettings
        // );
        // if (response.status !== 204) {
        //   const err = await ServerConnection.ResponseError.create(response);
        //   throw err;
        // }
    }
    /**
     * Delete a checkpoint for a file. Disabled for now.
     *
     * @param localPath - The path of the file.
     *
     * @param checkpointID - The id of the checkpoint to delete.
     *
     * @returns A promise which resolves when the checkpoint is deleted.
     *
     * #### Notes
     * Uses the [Jupyter Notebook API](https://petstore.swagger.io/?url=https://raw.githubusercontent.com/jupyter-server/jupyter_server/main/jupyter_server/services/api/api.yaml#!/contents).
     */
    async deleteCheckpoint(localPath, checkpointID) {
        // const url = this._getUrl(localPath, 'checkpoints', checkpointID);
        // const init = { method: 'DELETE' };
        // const response = await ServerConnection.makeRequest(
        //   url,
        //   init,
        //   this.serverSettings
        // );
        // if (response.status !== 204) {
        //   const err = await ServerConnection.ResponseError.create(response);
        //   throw err;
        // }
    }
    /**
     * Get a REST url for a file given a path.
     */
    _getUrl(...args) {
        const parts = args.map(path => _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.URLExt.encodeParts(path));
        const baseUrl = this.serverSettings.baseUrl;
        if (!baseUrl) {
            throw new Error('Jupyter server URL not set');
        }
        return _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.URLExt.join(baseUrl, this._apiEndpoint, ...parts);
    }
    async refreshBrowser() {
        // Use the tracker to find the file browser for this drive
        const fileBrowser = this.browser.tracker.find((widget) => widget.model.driveName === this.name);
        if (fileBrowser) {
            await fileBrowser.model.refresh(); // Refresh the file browser model
        }
        else {
            console.warn(`No file browser found for drive: ${this.name}`);
        }
    }
    _apiEndpoint;
    _isDisposed = false;
    _fileChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal(this);
}
/**
 * A namespace for module private data.
 */
var Private;
(function (Private) {
    /**
     * Normalize a file extension to be of the type `'.foo'`.
     *
     * Adds a leading dot if not present and converts to lower case.
     */
    function normalizeExtension(extension) {
        if (extension.length > 0 && extension.indexOf('.') !== 0) {
            extension = `.${extension}`;
        }
        return extension;
    }
    Private.normalizeExtension = normalizeExtension;
    /**
     * Validate a property as being on an object, and optionally
     * of a given type and among a given set of values.
     */
    function validateProperty(
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    object, name, typeName, values = []) {
        if (!object.hasOwnProperty(name)) {
            throw Error(`Missing property '${name}'`);
        }
        const value = object[name];
        if (typeName !== void 0) {
            let valid = true;
            switch (typeName) {
                case 'array':
                    valid = Array.isArray(value);
                    break;
                case 'object':
                    valid = typeof value !== 'undefined';
                    break;
                default:
                    valid = typeof value === typeName;
            }
            if (!valid) {
                throw new Error(`Property '${name}' is not of type '${typeName}'`);
            }
            if (values.length > 0) {
                let valid = true;
                switch (typeName) {
                    case 'string':
                    case 'number':
                    case 'boolean':
                        valid = values.includes(value);
                        break;
                    default:
                        valid = values.findIndex(v => v === value) >= 0;
                        break;
                }
                if (!valid) {
                    throw new Error(`Property '${name}' is not one of the valid values ${JSON.stringify(values)}`);
                }
            }
        }
    }
    Private.validateProperty = validateProperty;
    function validateContentsModel(model) {
        validateProperty(model, 'name', 'string');
        validateProperty(model, 'path', 'string');
        validateProperty(model, 'type', 'string');
        validateProperty(model, 'created', 'string');
        validateProperty(model, 'last_modified', 'string');
        validateProperty(model, 'mimetype', 'object');
        validateProperty(model, 'content', 'object');
        validateProperty(model, 'format', 'object');
    }
    Private.validateContentsModel = validateContentsModel;
    /**
     * Validate an `Contents.ICheckpointModel` object.
     */
    function validateCheckpointModel(model) {
        validateProperty(model, 'id', 'string');
        validateProperty(model, 'last_modified', 'string');
    }
    Private.validateCheckpointModel = validateCheckpointModel;
    function transformItem(item, localPath) {
        if (!item) {
            throw new Error("Item is missing or undefined.");
        }
        const figlinqType = item?.category || item?.filetype;
        const itemType = FILETYPE_TO_TYPE[figlinqType] || "file";
        const mimetype = _icons__WEBPACK_IMPORTED_MODULE_5__.FILETYPE_TO_ICON[figlinqType || ""].mimeTypes[0] || null;
        const newLocalPath = localPath ? `${localPath}/${item.filename}` : item.filename;
        return {
            name: item.filename || "",
            path: newLocalPath,
            last_modified: item.date_modified,
            created: item.creation_time,
            content: null,
            format: null,
            mimetype,
            size: null,
            writable: true,
            hash: null,
            hash_algorithm: null,
            type: itemType,
        };
    }
    // export function convertToJupyterApi(plotlyObject: any, fileType: string | undefined, fileName: string | null, action: string, localPath: string, lookup: any ): any {
    function convertToJupyterApi(convOptions) {
        // console.log('convertToJupyterApi start', convOptions);
        const { data, type, name, path, created, last_modified } = convOptions;
        const mimetype = TYPE_TO_MIMETYPE[type || ""] || null;
        let format = TYPE_TO_FORMAT[type || ""] || null;
        let transformedData = data?.children ? (data.children?.results || []).map((item) => transformItem(item, path)) : data;
        const model = {
            name,
            path,
            last_modified,
            created,
            content: transformedData,
            format,
            mimetype,
            size: null,
            writable: true,
            hash: null,
            hash_algorithm: null,
            type,
        };
        // console.log('convertToJupyterApi end', model);
        return model;
    }
    Private.convertToJupyterApi = convertToJupyterApi;
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/icons.js":
/*!**********************!*\
  !*** ./lib/icons.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FILETYPE_TO_ICON: () => (/* binding */ FILETYPE_TO_ICON),
/* harmony export */   createFiglinqIcon: () => (/* binding */ createFiglinqIcon),
/* harmony export */   createIcon: () => (/* binding */ createIcon),
/* harmony export */   figlinqLogo: () => (/* binding */ figlinqLogo),
/* harmony export */   getFileTypeToIcon: () => (/* binding */ getFileTypeToIcon)
/* harmony export */ });
/* harmony import */ var _mdi_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @mdi/js */ "webpack/sharing/consume/default/@mdi/js/@mdi/js");
/* harmony import */ var _mdi_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdi_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);


const figlinqLogo = `<svg viewBox="0 0 130 130" width="24" height="24" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg">
 <defs>
  <style>.cls-1,.cls-2{fill:#07547d;}.cls-2{stroke:#07547d;stroke-miterlimit:10;}.cls-3{fill:#55bbe7;}</style>
 </defs>
 <g class="layer">
  <title>Layer 1</title>
  <g id="svg_29">
   <path class="cls-2" d="m89.140001,25.165131a11.38,11.38 0 1 1 11.38,-11.37a11.38,11.38 0 0 1 -11.38,11.37zm0,-15.54a4.17,4.17 0 1 0 4.2,4.17a4.17,4.17 0 0 0 -4.2,-4.17z" id="svg_24"/>
   <path class="cls-2" d="m82.260001,17.395131a7.75,7.75 0 0 1 0,-7.21l-34.52,0a7.75,7.75 0 0 1 0,7.21l34.52,0z" id="svg_23"/>
   <path class="cls-2" d="m100.610001,10.185131l-4.59,0a7.75,7.75 0 0 1 0,7.21l4.59,0a12,12 0 0 1 12,12l0,27.78a7.75,7.75 0 0 1 7.21,0l0,-27.78a19.23,19.23 0 0 0 -19.21,-19.21z" id="svg_22"/>
   <path class="cls-2" d="m13.790001,88.155131a11.37,11.37 0 1 1 11.37,-11.37a11.39,11.39 0 0 1 -11.37,11.37zm0,-15.54a4.17,4.17 0 1 0 4.16,4.17a4.17,4.17 0 0 0 -4.16,-4.17z" id="svg_21"/>
   <path class="cls-2" d="m65.000001,127.595131a11.38,11.38 0 1 1 11.34,-11.38a11.39,11.39 0 0 1 -11.34,11.38zm0,-15.54a4.17,4.17 0 1 0 4.17,4.16a4.17,4.17 0 0 0 -4.17,-4.16z" id="svg_20"/>
   <path class="cls-2" d="m116.210001,71.825131a7.79,7.79 0 0 1 -3.6,-0.88l0,29.67a12,12 0 0 1 -12,12l-28.73,0a7.75,7.75 0 0 1 0,7.21l28.73,0a19.23,19.23 0 0 0 19.21,-19.21l0,-29.67a7.83,7.83 0 0 1 -3.61,0.88z" fill="black" id="svg_19"/>
   <path class="cls-2" d="m57.230001,116.215131a7.67,7.67 0 0 1 0.89,-3.6l-28.73,0a12,12 0 0 1 -12,-12l0,-17a7.75,7.75 0 0 1 -7.21,0l0,17a19.23,19.23 0 0 0 19.21,19.21l28.73,0a7.71,7.71 0 0 1 -0.89,-3.61z" id="svg_18"/>
   <path class="cls-2" d="m40.860001,25.165131a11.38,11.38 0 1 1 11.37,-11.37a11.39,11.39 0 0 1 -11.37,11.37zm0,-15.54a4.17,4.17 0 1 0 4.16,4.17a4.17,4.17 0 0 0 -4.16,-4.17z" id="svg_17"/>
   <path class="cls-2" d="m116.210001,75.435131a11.38,11.38 0 1 1 11.37,-11.38a11.38,11.38 0 0 1 -11.37,11.38zm0,-15.54a4.17,4.17 0 1 0 4.13,4.16a4.17,4.17 0 0 0 -4.13,-4.16z" id="svg_16"/>
   <rect class="cls-2" height="7.2" id="svg_15" width="28.92" x="58.380001" y="47.015131"/>
   <rect class="cls-2" height="7.2" id="svg_14" width="7.89" x="97.720001" y="60.455131"/>
   <rect class="cls-2" height="7.2" id="svg_13" width="27.07" x="38.990001" y="82.715131"/>
   <rect class="cls-2" height="7.2" id="svg_12" width="19.32" x="21.530001" y="73.185131"/>
   <rect class="cls-2" height="23.47" id="svg_11" width="7.2" x="61.400001" y="85.645131"/>
   <rect class="cls-2" height="22.39" id="svg_10" width="7.2" x="85.540001" y="20.955131"/>
   <rect class="cls-2" height="36.49" id="svg_9" width="7.2" x="37.250001" y="20.955131"/>
   <path class="cls-2" d="m13.790001,69.005131a7.8,7.8 0 0 1 3.6,0.89l0,-40.5a12,12 0 0 1 12,-12l4.58,0a7.82,7.82 0 0 1 0,-7.21l-4.58,0a19.23,19.23 0 0 0 -19.21,19.21l0,40.51a7.84,7.84 0 0 1 3.61,-0.9z" id="svg_8"/>
   <g id="svg_28">
    <rect class="cls-3" height="57.48" id="svg_27" width="17.92" x="80.180001" y="41.215131"/>
    <rect class="cls-3" height="67.4" id="svg_26" width="17.92" x="56.040001" y="31.305131"/>
    <rect class="cls-3" fill="black" height="44.15" id="svg_25" width="17.92" x="31.900001" y="54.555131"/>
   </g>
  </g>
 </g>
</svg>`;
// Create a LabIcon instance
const createIcon = (name, path) => {
    const FILL = "#7e7e7e";
    const svgstr = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="${path}" fill="${FILL}" /></svg>`;
    return new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
        name,
        svgstr,
    });
};
// Create a LabIcon instance
const createFiglinqIcon = () => {
    return new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
        name: 'figlinq-logo',
        svgstr: figlinqLogo,
    });
};
const FILETYPE_TO_ICON = {
    'fold': {
        name: 'figlinq-folder',
        displayName: 'Figlinq Folder',
        mimeTypes: ['figlinq/folder'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiFolder,
    },
    'grid': {
        name: 'figlinq-grid',
        displayName: 'Figlinq Data Grid',
        mimeTypes: ['figlinq/grid'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiGrid,
    },
    'plot': {
        name: 'figlinq-plot',
        displayName: 'Figlinq Plot',
        mimeTypes: ['figlinq/plot'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiChartBoxOutline,
    },
    'figure': {
        name: 'figlinq-figure',
        displayName: 'Figlinq Figure',
        mimeTypes: ['figlinq/figure'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiViewDashboardOutline,
    },
    'dashboard': {
        name: 'figlinq-collection',
        displayName: 'Figlinq Collection',
        mimeTypes: ['figlinq/collection'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiPackageVariantClosed,
    },
    'external_image': {
        name: 'figlinq-external-image',
        displayName: 'Figlinq External Image',
        mimeTypes: ['figlinq/external-image'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiImageOutline,
    },
    'text': {
        name: 'figlinq-html-text',
        displayName: 'Figlinq Text',
        mimeTypes: ['figlinq/html-text'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiTextBoxOutline,
    },
    'jupyter_notebook': {
        name: 'figlinq-jupyter-notebook',
        displayName: 'Figlinq Jupyter Notebook',
        mimeTypes: ['figlinq/jupyter-notebook'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiFileCodeOutline,
    },
    'agent': {
        name: 'figlinq-agent',
        displayName: 'Figlinq Agent',
        mimeTypes: ['figlinq/agent'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiFaceAgent,
    },
    'agent_team': {
        name: 'figlinq-agent-team',
        displayName: 'Figlinq Agent Team',
        mimeTypes: ['figlinq/agent-team'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiAccountGroup,
    },
    'agent_tool': {
        name: 'figlinq-agent-tool',
        displayName: 'Figlinq Agent Tool',
        mimeTypes: ['figlinq/agent-tool'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiTools,
    },
    'agent_workflow': {
        name: 'figlinq-agent-workflow',
        displayName: 'Figlinq Agent Workflow',
        mimeTypes: ['figlinq/agent-workflow'],
        extensions: [],
        icon: _mdi_js__WEBPACK_IMPORTED_MODULE_0__.mdiFormatListText,
    },
};
const getFileTypeToIcon = () => {
    const icons = {};
    for (const key in FILETYPE_TO_ICON) {
        const name = FILETYPE_TO_ICON[key].name;
        const icon = FILETYPE_TO_ICON[key];
        icon.icon = createIcon(name, icon.icon);
        icons[key] = icon;
    }
    return icons;
};


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _serverconnection__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./serverconnection */ "./lib/serverconnection.js");
/* harmony import */ var _drive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./drive */ "./lib/drive.js");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/docregistry */ "webpack/sharing/consume/default/@jupyterlab/docregistry");
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _commands__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./commands */ "./lib/commands.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./icons */ "./lib/icons.js");















const DRIVE_NAME = 'Figlinq';
const REMOVE_LAUNCHER_COMMANDS = ['fileeditor:create-new', 'fileeditor:create-new-markdown-file'];
// Iframe communication
// const callParent = (action:string) =>
//   new Promise((res, rej) => {
//     const channel = new MessageChannel();
//     channel.port1.onmessage = ({data}) => {
//       channel.port1.close();
//       if (data.error) {
//         rej(data.error);
//       } else {
//         res(data.result);
//       }
//     };
//     parent.postMessage([action], '*', [channel.port2]);
//   });
// Define the custom implementation for _maybeOverWrite to skip deleting the file in figlinq
async function customMaybeOverWrite(path) {
    const body = this._trans.__('"%1" already exists. Do you want to replace it?', path);
    const overwriteBtn = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.warnButton({
        label: this._trans.__('Overwrite'),
        accept: true
    });
    return (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
        title: this._trans.__('File Overwrite?'),
        body,
        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.cancelButton(), overwriteBtn]
    }).then(result => {
        if (this.isDisposed) {
            return Promise.reject(new Error('Disposed'));
        }
        if (result.button.accept) {
            // Skip deleting the file, just proceed with the save operation.
            return this._finishSaveAs(path);
        }
    });
}
// Override the method on the prototype, bypassing the private visibility restriction
_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_5__.Context.prototype._maybeOverWrite = customMaybeOverWrite;
/**
 * Loads a file from URL parameters and opens it in the document manager.
 *
 * @param commands - The command registry used to execute commands.
 * @param widget - The widget whose model will be updated with the file's directory path.
 *
 * This function retrieves the file ID (fid) from the URL parameters. If the fid is present,
 * it constructs a URL to fetch the file path associated with the fid. If the fetch request
 * is successful, it opens the file using the document manager and updates the widget's model
 * with the directory path of the file. If the fetch request fails or an error occurs while
 * opening the file, an error dialog is displayed.
 */
const loadFileFromUrlParams = async (commands, widget) => {
    const urlParams = new URLSearchParams(window.parent.location.search);
    const fid = urlParams.get('fid') || '';
    if (fid) {
        // GET file path from fid
        let cdPath = '/';
        const parts = [
            _drive__WEBPACK_IMPORTED_MODULE_9__.SERVICE_DRIVE_URL,
            'files',
            fid,
            'path'
        ];
        const partsEncoded = parts.map(part => _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_7__.URLExt.encodeParts(part));
        const url = '/' + partsEncoded.join('/');
        const showErrorDialog = () => {
            (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
                title: 'FIle loading error',
                body: `Failed to load file with id ${fid}.`,
                buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton({ label: 'OK' })]
            });
        };
        const response = await fetch(url);
        if (!response.ok) {
            showErrorDialog();
        }
        else {
            const data = await response.json();
            try {
                commands.execute('docmanager:open', { path: `${DRIVE_NAME}:${data.path}` });
                const pathSplit = data.path.split('/');
                if (pathSplit.length > 1) {
                    cdPath = pathSplit.slice(0, pathSplit.length - 1).join('/');
                }
            }
            catch (error) {
                showErrorDialog();
            }
        }
        widget.model.cd(cdPath);
    }
};
/**
 * Disables the default file browser in a JupyterFrontEnd application.
 *
 * This function attempts to find and dispose of the default file browser widget
 * in the left sidebar of the JupyterLab interface. If the default file browser
 * is found, it is disposed of and the remote contents browser is activated.
 * If the default file browser is not found immediately, a periodic timer is
 * used to check for the file browser every 100 milliseconds until it is found
 * and handled.
 *
 * @param app - The JupyterFrontEnd application instance.
 */
const disableDefaultFileBrowser = (app) => {
    const handleFileBrowser = () => {
        const widgets = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_4__.toArray)(app.shell.widgets('left'));
        const defaultBrowser = widgets.find(widget => widget.id === 'filebrowser');
        if (defaultBrowser) {
            defaultBrowser.dispose();
            app.shell.activateById('jp-remote-contents-browser');
            return true; // Found and handled
        }
        return false; // Not found
    };
    // Disable the default file browser
    // Try finding the file browser immediately
    if (!handleFileBrowser()) {
        // Fallback: Use a periodic timer to check for the file browser
        const interval = setInterval(() => {
            if (handleFileBrowser()) {
                clearInterval(interval); // Stop checking once handled
            }
        }, 100); // Check every 100ms
    }
};
/**
 * Defines custom rename, to skip the drive check (which gives an error when dropping onto root folder).
 *
 * @param this - The context in which the function is called.
 * @param path - The current path of the file or directory to be renamed.
 * @param newPath - The new path for the file or directory.
 * @returns A promise that resolves to the updated contents model with the new path.
 *
 * @throws Error if renaming files across different drives is attempted.
 */
async function customRename(path, newPath) {
    const [drive1, path1] = this._driveForPath(path);
    const [, path2] = this._driveForPath(newPath);
    // Disable the drive check, we only have one drive
    // if (drive1 !== drive2 && newPath !== '') {
    //     throw Error('ContentsManager: renaming files must occur within a Drive');
    // }
    return drive1.rename(path1, path2).then((contentsModel) => {
        return Object.assign(Object.assign({}, contentsModel), { path: this._toGlobalPath(drive1, path2) });
    });
}
/**
 * Register custom file types
 * @param app The JupyterFrontEnd instance
 * @returns void
 *
**/
function registerCustomFileTypes(app) {
    const registry = app.docRegistry;
    const filetypeToIcon = (0,_icons__WEBPACK_IMPORTED_MODULE_10__.getFileTypeToIcon)();
    // Add a custom file types from FILETYPE_TO_ICON object
    Object.keys(filetypeToIcon).forEach(fileType => {
        const fileTypeData = filetypeToIcon[fileType];
        registry.addFileType({
            name: fileTypeData.name,
            displayName: fileTypeData.displayName,
            mimeTypes: fileTypeData.mimeTypes,
            extensions: fileTypeData.extensions,
            icon: fileTypeData.icon,
        });
    });
}
/**
 * Initialization data for the jupyterlab-remote-contents extension.
 */
const plugin = {
    id: 'jupyterlab-remote-contents:plugin',
    requires: [_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.IFileBrowserFactory, _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__.ITranslator, _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_6__.ILauncher, _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_8__.INotebookTracker],
    autoStart: true,
    activate: (app, browser, translator, launcher, notebookTracker) => {
        const { serviceManager, commands, docRegistry } = app;
        const { createFileBrowser } = browser;
        const originalAdd = launcher.add;
        // Override the launcher.add method to filter out unwanted commands
        launcher.add = (options) => {
            if (REMOVE_LAUNCHER_COMMANDS.includes(options.command)) {
                const noOpDisposable = {
                    isDisposed: false,
                    dispose: () => {
                        /* no-op */
                    }
                };
                return noOpDisposable; // Return a no-op disposable
            }
            // Call the original add method for other items
            return originalAdd.call(launcher, options);
        };
        const trans = translator.load('jupyterlab-remote-contents');
        const serverSettings = _serverconnection__WEBPACK_IMPORTED_MODULE_11__.ServerConnection.makeSettings();
        const drive = new _drive__WEBPACK_IMPORTED_MODULE_9__.Drive({ serverSettings, name: DRIVE_NAME, browser });
        serviceManager.contents.addDrive(drive);
        const widget = createFileBrowser('jp-remote-contents-browser', {
            driveName: drive.name,
            // We don't want to restore old state, we don't have a drive handle ready
            restore: false
        });
        widget.title.caption = trans.__('My files');
        widget.title.icon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.folderIcon;
        const createNewDirectoryButton = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButton({
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.newFolderIcon,
            onClick: async () => {
                widget.createNewDirectory();
            },
            tooltip: trans.__('New Folder')
        });
        const uploader = new _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.Uploader({ model: widget.model, translator });
        const refreshButton = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButton({
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.refreshIcon,
            onClick: async () => {
                widget.model.refresh();
            },
            tooltip: trans.__('Refresh File Browser')
        });
        const searcher = (0,_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.FilenameSearcher)({
            updateFilter: (filterFn, query) => {
                widget.model.setFilter(value => {
                    return filterFn(value.name.toLowerCase());
                });
            },
            useFuzzyFilter: true,
            placeholder: trans.__('Filter files by name'),
            forceRefresh: true
        });
        widget.toolbar.insertItem(1, 'create-new-directory', createNewDirectoryButton);
        widget.toolbar.insertItem(2, 'upload', uploader);
        widget.toolbar.insertItem(3, 'refresh', refreshButton);
        widget.toolbar.insertItem(4, 'search', searcher);
        (0,_commands__WEBPACK_IMPORTED_MODULE_12__.addContextMenuCommands)(commands, notebookTracker, app, widget);
        (0,_commands__WEBPACK_IMPORTED_MODULE_12__.addNotebookToolbarMenu)(commands, notebookTracker, app);
        registerCustomFileTypes(app);
        // Override the original getFileTypeForModel method to handle custom MIME types
        const originalGetFileTypeForModel = docRegistry.getFileTypeForModel;
        docRegistry.getFileTypeForModel = function (model) {
            const fileTypesArray = Array.from(this.fileTypes());
            if (model.mimetype) {
                const mimeMatch = fileTypesArray.find(ft => ft.mimeTypes.includes(model.mimetype));
                if (mimeMatch) {
                    return mimeMatch;
                }
            }
            // Fallback to the original behavior
            return originalGetFileTypeForModel.call(this, model);
        };
        app.shell.add(widget, 'left');
        loadFileFromUrlParams(commands, widget);
        disableDefaultFileBrowser(app);
        // Override the original rename command with our custom version to avoid drive check
        serviceManager.contents.rename = customRename.bind(serviceManager.contents);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/serverconnection.js":
/*!*********************************!*\
  !*** ./lib/serverconnection.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ServerConnection: () => (/* binding */ ServerConnection)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* provided dependency */ var process = __webpack_require__(/*! process/browser */ "./node_modules/process/browser.js");
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.

let WEBSOCKET;
if (typeof window === 'undefined') {
    // Mangle the require statements so it does not get picked up in the
    // browser assets.
    WEBSOCKET = __webpack_require__(/*! ws */ "./node_modules/ws/browser.js");
}
else {
    WEBSOCKET = WebSocket;
}
/**
 * The namespace for ServerConnection functions.
 *
 * #### Notes
 * This is only intended to manage communication with the Jupyter server.
 *
 * The default values can be used in a JupyterLab or Jupyter Notebook context.
 *
 * We use `token` authentication if available, falling back on an XSRF
 * cookie if one has been provided on the `document`.
 *
 * A content type of `'application/json'` is added when using authentication
 * and there is no body data to allow the server to prevent malicious forms.
 */
var ServerConnection;
(function (ServerConnection) {
    /**
     * Create a settings object given a subset of options.
     *
     * @param options - An optional partial set of options.
     *
     * @returns The full settings object.
     */
    function makeSettings(options) {
        return Private.makeSettings(options);
    }
    ServerConnection.makeSettings = makeSettings;
    /**
     * Make an request to the notebook server.
     *
     * @param url - The url for the request.
     *
     * @param init - The initialization options for the request.
     *
     * @param settings - The server settings to apply to the request.
     *
     * @returns a Promise that resolves with the response.
     *
     * @throws If the url of the request is not a notebook server url.
     *
     * #### Notes
     * The `url` must start with `settings.baseUrl`.  The `init` settings are
     * merged with `settings.init`, with `init` taking precedence.
     * The headers in the two objects are not merged.
     * If there is no body data, we set the content type to `application/json`
     * because it is required by the Notebook server.
     */
    function makeRequest(settings, url, init, params) {
        const queryParams = { ...params };
        const urlWithQueryParams = url + _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.objectToQueryString(queryParams);
        return Private.handleRequest(urlWithQueryParams, init, settings);
    }
    ServerConnection.makeRequest = makeRequest;
    /**
     * A wrapped error for a fetch response.
     */
    class ResponseError extends Error {
        /**
         * Create a ResponseError from a response, handling the traceback and message
         * as appropriate.
         *
         * @param response The response object.
         *
         * @returns A promise that resolves with a `ResponseError` object.
         */
        static async create(response) {
            try {
                const data = await response.json();
                const message = data.errors?.[0]?.message;
                return new ResponseError(response, message, '');
            }
            catch (e) {
                console.debug(e);
                return new ResponseError(response);
            }
        }
        /**
         * Create a new response error.
         */
        constructor(response, message = ResponseError._defaultMessage(response), traceback = '') {
            super(message);
            this.response = response;
            this.traceback = traceback;
        }
        /**
         * The response associated with the error.
         */
        response;
        /**
         * The traceback associated with the error.
         */
        traceback;
        static _defaultMessage(response) {
            return `Invalid response: ${response.status} ${response.statusText}`;
        }
    }
    ServerConnection.ResponseError = ResponseError;
    /**
     * A wrapped error for a network error.
     */
    class NetworkError extends TypeError {
        /**
         * Create a new network error.
         */
        constructor(original) {
            super(original.message);
            this.stack = original.stack;
        }
    }
    ServerConnection.NetworkError = NetworkError;
})(ServerConnection || (ServerConnection = {}));
/**
 * The namespace for module private data.
 */
var Private;
(function (Private) {
    /**
     * Handle the server connection settings, returning a new value.
     */
    function makeSettings(options = {}) {
        const pageBaseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getBaseUrl();
        const pageWsUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getWsUrl();
        const baseUrl = options.baseUrl || window.location.origin;
        const queryParams = options.queryParams || {};
        let wsUrl = options.wsUrl;
        // Prefer the default wsUrl if we are using the default baseUrl.
        if (!wsUrl && baseUrl === pageBaseUrl) {
            wsUrl = pageWsUrl;
        }
        // Otherwise convert the baseUrl to a wsUrl if possible.
        if (!wsUrl && baseUrl.indexOf('http') === 0) {
            wsUrl = 'ws' + baseUrl.slice(4);
        }
        // Otherwise fall back on the default wsUrl.
        wsUrl = wsUrl ?? pageWsUrl;
        const defaultSerializer = {
            serialize: (data) => JSON.stringify(data),
            deserialize: (data) => JSON.parse(data)
        };
        return {
            init: { cache: 'no-store', credentials: 'same-origin' },
            fetch,
            Headers,
            Request,
            WebSocket: WEBSOCKET,
            token: _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getToken(),
            appUrl: _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getOption('appUrl'),
            appendToken: typeof window === 'undefined' ||
                (typeof process !== 'undefined' &&
                    process?.env?.JEST_WORKER_ID !== undefined) ||
                _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.getHostName(pageBaseUrl) !== _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.getHostName(wsUrl),
            ...options,
            baseUrl,
            queryParams,
            wsUrl,
            serializer: defaultSerializer
        };
    }
    Private.makeSettings = makeSettings;
    /**
     * Handle a request.
     *
     * @param url - The url for the request.
     *
     * @param init - The overrides for the request init.
     *
     * @param settings - The settings object for the request.
     *
     * #### Notes
     * The `url` must start with `settings.baseUrl`.  The `init` settings
     * take precedence over `settings.init`.
     */
    function handleRequest(url, init, settings) {
        // Handle notebook server requests.
        if (url.indexOf(settings.baseUrl) !== 0) {
            throw new Error('Can only be used for notebook server requests');
        }
        // Use explicit cache buster when `no-store` is set since
        // not all browsers use it properly.
        // const cache = init.cache ?? settings.init.cache;
        // if (cache === 'no-store') {
        //   // https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/Using_XMLHttpRequest#Bypassing_the_cache
        //   url += (/\?/.test(url) ? '&' : '?') + new Date().getTime();
        // }
        const request = new settings.Request(url, { ...settings.init, ...init });
        // Handle authentication. Authentication can be overdetermined by
        // settings token and XSRF token.
        let authenticated = false;
        if (typeof document !== 'undefined' && document?.cookie) {
            const xsrfToken = getCookie('plotly_csrf_on');
            if (xsrfToken !== undefined) {
                authenticated = true;
                request.headers.append('x-csrftoken', xsrfToken);
            }
        }
        request.headers.append('plotly-client-platform', 'web - jupyterlite');
        // Set the content type if there is no given data and we are
        // using an authenticated connection.
        if (!request.headers.has('Content-Type') && authenticated) {
            request.headers.set('Content-Type', 'application/json');
        }
        // Use `call` to avoid a `TypeError` in the browser.
        return settings.fetch.call(null, request).catch((e) => {
            // Convert the TypeError into a more specific error.
            throw new ServerConnection.NetworkError(e);
        });
        // TODO: *this* is probably where we need a system-wide connectionFailure
        // signal we can hook into.
    }
    Private.handleRequest = handleRequest;
    /**
     * Get a cookie from the document.
     */
    function getCookie(name) {
        // From http://www.tornadoweb.org/en/stable/guide/security.html
        const matches = document.cookie.match('\\b' + name + '=([^;]*)\\b');
        return matches?.[1];
    }
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/snippets.js":
/*!*************************!*\
  !*** ./lib/snippets.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SNIPPETS: () => (/* binding */ SNIPPETS)
/* harmony export */ });
const ORIGIN = window.parent.location.origin;
const SNIPPETS = {
    installChartStudio: `# Patch http requests (required for importing data into Python execution environment)
import pyodide_http
pyodide_http.patch_all()

# Install Chart Studio package to interact with Figlinq datasets and charts
%pip install chart_studio

# Import required libraries
import chart_studio

# Set credentials and privacy settings
chart_studio.tools.set_config_file(
    plotly_domain='${ORIGIN}',
    plotly_api_domain='${ORIGIN}',
    world_readable=False,
    sharing='private'
)

# To generate/view your API key, visit ${ORIGIN}/settings/api
chart_studio.tools.set_credentials_file(username='YOUR_USERNAME', api_key='YOUR_API_KEY')

# Create traces
trace0 = go.Scatter(
    x=[1, 2, 3, 4],
    y=[10, 15, 13, 17]
)
trace1 = go.Scatter(
    x=[1, 2, 3, 4],
    y=[16, 5, 11, 9]
)
data = [trace0, trace1]

# Set some basic plot styling
layout=go.Layout(
    width=400,
    height=360,
    autosize=False,
    plot_bgcolor='white',
    title=dict(
        text='Example Plot with Custom Styling',
    ),
    xaxis=dict(
        title='X Axis',
    ),
    yaxis=dict(
        title='Y Axis',
    ),
)

# Create plot and save to Figlinq
fig = go.Figure(data=data, layout=layout)
py.plot(fig, filename = 'Simple line chart')
`,
    patchHttp: `# Patch http requests (required for importing data into Python execution environment)
import pyodide_http
pyodide_http.patch_all()`
};


/***/ }),

/***/ "./node_modules/process/browser.js":
/*!*****************************************!*\
  !*** ./node_modules/process/browser.js ***!
  \*****************************************/
/***/ ((module) => {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),

/***/ "./node_modules/ws/browser.js":
/*!************************************!*\
  !*** ./node_modules/ws/browser.js ***!
  \************************************/
/***/ ((module) => {

"use strict";


module.exports = function () {
  throw new Error(
    'ws does not work in the browser. Browser clients must use the native ' +
      'WebSocket object'
  );
};


/***/ })

}]);
//# sourceMappingURL=lib_index_js.6c4b7848e86d8e316c3e.js.map